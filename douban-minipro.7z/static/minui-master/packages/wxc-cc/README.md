# wxc-cc

> MinUI 小程序组件 - 水平垂直居中

## Install

``` bash
$ min install @minui/wxc-cc
```

## API

### CC【props】

none

## Link
||地址|
|--|---|
||cc 组件文档 <br> [https://meili.github.io/min/docs/minui/index.html#cc](https://meili.github.io/min/docs/minui/index.html#cc)<br>|
||cc 组件源码 <br> [https://github.com/meili/minui/tree/master/packages/wxc-cc](https://github.com/meili/minui/tree/master/packages/wxc-cc)<br>|
||MinUI 组件库 <br> [https://github.com/meili/minui](https://github.com/meili/minui) <br>|

## Preview
![cc](https://s10.mogucdn.com/mlcdn/c45406/171115_2b7djgj18g4gifdkljf60b70kd75k_480x480.jpg_225x999.jpg)

## ChangeLog

#### v1.0.0（2017-11-15）

- 初始版本
